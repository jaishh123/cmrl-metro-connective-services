# Import preview and validation report

Workbook: **Monthwise_Daily_Performance_of_Metro_Connect_Services.xlsx**  
SHA-256: `0c7767161c449dc3d5a7bd80861377e17dcb7147a7f5221ea16da2dbd3dbb71c`  
Nothing has been written to any database. The workbook was only read.

## Summary

| Item | Count |
|---|---:|
| Daily records to import | 5496 |
| Monthly records to import | 168 |
| Errors (records rejected) | 0 |
| Warnings | 0 |
| Real zero values preserved | 779 |
| Cumulative cells compared | 6906 |
| Cumulative mismatches | 26 |

## Sheets read (none skipped)

| Sheet | Type | Range | Records |
|---|---|---|---:|
| April 25 | monthly daily-values | 2025-04-01 to 2025-04-30 | 330 |
| May 25 | monthly daily-values | 2025-05-01 to 2025-05-31 | 368 |
| June 25 | monthly daily-values | 2025-06-01 to 2025-06-30 | 360 |
| July 25 | monthly daily-values | 2025-07-01 to 2025-07-31 | 368 |
| Aug '25 | monthly daily-values | 2025-08-01 to 2025-08-31 | 369 |
| SEP '25 | monthly daily-values | 2025-09-01 to 2025-09-30 | 350 |
| OCT-25 | monthly daily-values | 2025-10-01 to 2025-10-31 | 368 |
| Nov-25 | monthly daily-values | 2025-11-01 to 2025-11-30 | 354 |
| Dec-25 | monthly daily-values | 2025-12-01 to 2025-12-31 | 372 |
| Jan-26 | monthly daily-values | 2026-01-01 to 2026-01-31 | 358 |
| Feb-26 | monthly daily-values | 2026-02-01 to 2026-02-28 | 212 |
| Mar-26 | monthly daily-values | 2026-03-01 to 2026-03-31 | 201 |
| Apr-26 | monthly daily-values | 2026-04-01 to 2026-04-30 | 258 |
| May-26 | monthly daily-values | 2026-05-01 to 2026-05-31 | 279 |
| Jun-26 | monthly daily-values | 2026-06-01 to 2026-06-30 | 270 |
| Jul-26 | monthly daily-values | 2026-07-01 to 2026-07-31 | 267 |
| Aug-26 | monthly daily-values | 2026-08-01 to 2026-08-31 | 212 |
| SEP-26 | monthly daily-values | 2026-09-01 to 2026-09-30 | 137 |
| OCT-26 | monthly daily-values | 2026-10-01 to 2026-10-31 | 63 |
| Pallavaram detailed analysis | Pallavaram monthly (source of truth) |  | 84 |
| SC-GBS performance | SC-GBS monthly |  | 81 |
| Sheet1 | Older Pallavaram copy (superseded) |  | 0 |

## Daily records by domain and metric

| Domain | Metric | Records | First date | Last date |
|---|---|---:|---|---|
| DLF Cybercity | daily_performance | 559 | 2025-04-01 | 2026-10-21 |
| ITPC | daily_performance | 554 | 2025-04-01 | 2026-10-21 |
| Keppel | daily_performance | 552 | 2025-04-01 | 2026-10-21 |
| Kosmo One | daily_performance | 548 | 2025-04-01 | 2026-09-30 |
| MTC | gap | 303 | 2025-04-01 | 2026-01-31 |
| MTC | revenue | 303 | 2025-04-01 | 2026-01-31 |
| MTC | ridership | 303 | 2025-04-01 | 2026-01-31 |
| Pallavaram Parking | revenue | 527 | 2025-04-01 | 2026-09-09 |
| Pallavaram Parking | vehicle_count | 527 | 2025-04-01 | 2026-09-09 |
| SC-GBS | daily_performance | 458 | 2025-05-01 | 2026-08-31 |
| Thirumangalam Parking | revenue | 431 | 2025-04-01 | 2026-07-26 |
| Thirumangalam Parking | vehicle_count | 431 | 2025-04-01 | 2026-07-26 |

## Monthly records by domain and metric

| Domain | Metric | Records | First month | Last month |
|---|---|---:|---|---|
| Pallavaram Parking | avg_days | 3 | 2025-01 | 2026-09 |
| Pallavaram Parking | connectivity_expenditure | 21 | 2025-01 | 2026-09 |
| Pallavaram Parking | difference | 21 | 2025-01 | 2026-09 |
| Pallavaram Parking | monthly_revenue | 21 | 2025-01 | 2026-09 |
| Pallavaram Parking | monthly_vehicle_count | 21 | 2025-01 | 2026-09 |
| SC-GBS | alandur_contribution_a | 9 | 2025-04 | 2025-12 |
| SC-GBS | alandur_contribution_b | 9 | 2025-04 | 2025-12 |
| SC-GBS | alandur_entry_avg_day | 9 | 2025-04 | 2025-12 |
| SC-GBS | alandur_entry_monthly | 9 | 2025-04 | 2025-12 |
| SC-GBS | alandur_exit_avg_day | 9 | 2025-04 | 2025-12 |
| SC-GBS | alandur_exit_monthly | 9 | 2025-04 | 2025-12 |
| SC-GBS | cmrl_ridership_entry_monthly | 9 | 2025-04 | 2025-12 |
| SC-GBS | daily_average_rider | 9 | 2025-04 | 2025-12 |
| SC-GBS | monthly_users | 9 | 2025-04 | 2025-12 |

## Outstanding issues (nothing here has been changed or hidden)

| # | Issue | Effect on the app | Decision needed |
|---|---|---|---|
| 1 | 26 SC-GBS cumulative cells differ from the month-to-date sum (cause below: a typed constant in cell G11) | The app shows the sum of the daily values; the workbook shows a lower number | Confirm the daily values are correct (recommended) |
| 2 | SC-GBS "Monthly Users" for 2025-06 is 2,508 but its 30 daily values add up to 2,923 (difference -415) | The monthly value is imported exactly as the workbook has it and is NOT recalculated | Keep 2,508, or correct it to 2,923 |
| 3 | 8 "column 1" contribution formulas point at the previous month's row | Imported as stored in the workbook; flagged | Confirm whether to keep the stored values or correct them |
| 4 | Pallavaram monthly figures differ from the sum of daily values in 1 month(s) | Both are kept; monthly and daily are separate | None required; for your awareness |
| 5 | SC-GBS "column 1 / column 2" contribution meaning not confirmed | Shown only as column 1 and column 2 | Confirm meanings (formula evidence below) |
| 6 | 3 Pallavaram "Days counted" helper values | Shown as a helper row, used only for Average per Day | Keep visible, or hide as a helper |

## 1. Cumulative check (month-to-date)

The app calculates cumulative values itself. 6906 workbook cumulative cells were compared; **26** differ.

**June 25 - SC-GBS daily_performance**: 26 cells, June 25!G11 to June 25!AF11, every one off by -415 (workbook minus calculated).

Root cause found in the workbook formulas: every cumulative cell is normally a formula "today + yesterday's cumulative" (for example `H10+G11`). In this row one cell is a typed constant instead of a formula, so the chain restarts there:

- `June 25!G11` (2025-06-05) holds the typed number **0**. The daily value that day is **102** (kept as is). The formula would have given **415**. The difference 415 is the total of the days before it, which the chain then forgets for the rest of the month.

The daily source values were not changed. Only the workbook cumulative cells are ignored in favour of the calculated month-to-date sum.

Typed constants found in cumulative rows across all 19 monthly sheets: **2**. 1 cause a mismatch (above). 1 are harmless because the typed value equals the calculated value: `May 25!G11` = 0.

| Cell | Domain | Metric | Date | Workbook | Calculated | Difference |
|---|---|---|---|---:|---:|---:|
| June 25!G11 | SC-GBS | daily_performance | 2025-06-05 | 0 | 415 | -415 |
| June 25!H11 | SC-GBS | daily_performance | 2025-06-06 | 104 | 519 | -415 |
| June 25!I11 | SC-GBS | daily_performance | 2025-06-07 | 104 | 519 | -415 |
| June 25!J11 | SC-GBS | daily_performance | 2025-06-08 | 104 | 519 | -415 |
| June 25!K11 | SC-GBS | daily_performance | 2025-06-09 | 215 | 630 | -415 |
| June 25!L11 | SC-GBS | daily_performance | 2025-06-10 | 330 | 745 | -415 |
| June 25!M11 | SC-GBS | daily_performance | 2025-06-11 | 439 | 854 | -415 |
| June 25!N11 | SC-GBS | daily_performance | 2025-06-12 | 547 | 962 | -415 |
| June 25!O11 | SC-GBS | daily_performance | 2025-06-13 | 655 | 1070 | -415 |
| June 25!P11 | SC-GBS | daily_performance | 2025-06-14 | 655 | 1070 | -415 |
| June 25!Q11 | SC-GBS | daily_performance | 2025-06-15 | 655 | 1070 | -415 |
| June 25!R11 | SC-GBS | daily_performance | 2025-06-16 | 727 | 1142 | -415 |
| June 25!S11 | SC-GBS | daily_performance | 2025-06-17 | 825 | 1240 | -415 |
| June 25!T11 | SC-GBS | daily_performance | 2025-06-18 | 922 | 1337 | -415 |
| June 25!U11 | SC-GBS | daily_performance | 2025-06-19 | 1011 | 1426 | -415 |
| June 25!V11 | SC-GBS | daily_performance | 2025-06-20 | 1104 | 1519 | -415 |
| June 25!W11 | SC-GBS | daily_performance | 2025-06-21 | 1104 | 1519 | -415 |
| June 25!X11 | SC-GBS | daily_performance | 2025-06-22 | 1104 | 1519 | -415 |
| June 25!Y11 | SC-GBS | daily_performance | 2025-06-23 | 1239 | 1654 | -415 |
| June 25!Z11 | SC-GBS | daily_performance | 2025-06-24 | 1439 | 1854 | -415 |
| June 25!AA11 | SC-GBS | daily_performance | 2025-06-25 | 1747 | 2162 | -415 |
| June 25!AB11 | SC-GBS | daily_performance | 2025-06-26 | 2022 | 2437 | -415 |
| June 25!AC11 | SC-GBS | daily_performance | 2025-06-27 | 2226 | 2641 | -415 |
| June 25!AD11 | SC-GBS | daily_performance | 2025-06-28 | 2226 | 2641 | -415 |
| June 25!AE11 | SC-GBS | daily_performance | 2025-06-29 | 2226 | 2641 | -415 |
| June 25!AF11 | SC-GBS | daily_performance | 2025-06-30 | 2508 | 2923 | -415 |

## 2. SC-GBS monthly users vs the sum of daily values

Cross-check of "Monthly Users" (SC-GBS performance sheet) against the daily values in the monthly sheets. Both are imported exactly as stored and kept separate; this only shows whether they agree.

| Month | Monthly Users (monthly sheet) | Sum of daily values | Days with data | Difference |
|---|---:|---:|---:|---:|
| 2025-05 | 379 | 379 | 30 | 0 (agrees) |
| 2025-06 | 2,508 | 2,923 | 30 | -415 |
| 2025-07 | 12,957 | 12,957 | 30 | 0 (agrees) |
| 2025-08 | 11,934 | 11,934 | 31 | 0 (agrees) |
| 2025-09 | 14,038 | 14,038 | 28 | 0 (agrees) |
| 2025-10 | 11,143 | 11,143 | 29 | 0 (agrees) |
| 2025-11 | 13,322 | 13,322 | 30 | 0 (agrees) |
| 2025-12 | 10,247 | 10,247 | 31 | 0 (agrees) |

Only 2025-06 disagrees. 2,508 equals the workbook's broken cumulative figure at the end of that month, so the monthly value was most likely taken from the faulty cumulative row. This is an inference, not a certainty, so nothing was changed.

## 3. SC-GBS "Alandur Contribution in CMRL ridership in %" (two identical headings)

They stay labelled **column 1** (workbook column I) and **column 2** (workbook column J). The workbook formulas show how each was calculated, but the names have not been assigned:

- Column 1 formula: `1-((H-D)/H)`, i.e. Alandur Entry (D) divided by Monthly CMRL Ridership Entry (H).
- Column 2 formula: `1-((H-E)/H)`, i.e. Alandur Exit (E) divided by the same CMRL Entry figure (H).
- The sheet has no "CMRL Exit" column, so both use the CMRL Entry total.

**Formula problem found:** in 8 cell(s) a formula refers to a different row than its own, so it uses another month's value. The stored values are imported unchanged:

| Cell | Month | Column | Formula | Rows referenced | Stored value | Value if the row were aligned |
|---|---|---|---|---|---:|---:|
| SC-GBS performance!I3 | 2025-05 | column 1 | `1-((H3-D2)/H3)` | 3, 2, 3 (own row 3) | 3.35% | 3.35% |
| SC-GBS performance!I4 | 2025-06 | column 1 | `1-((H4-D3)/H4)` | 4, 3, 4 (own row 4) | 3.24% | 3.34% |
| SC-GBS performance!I5 | 2025-07 | column 1 | `1-((H5-D4)/H5)` | 5, 4, 5 (own row 5) | 2.94% | 3.33% |
| SC-GBS performance!I6 | 2025-08 | column 1 | `1-((H6-D5)/H6)` | 6, 5, 6 (own row 6) | 3.52% | 3.37% |
| SC-GBS performance!I7 | 2025-09 | column 1 | `1-((H7-D6)/H7)` | 7, 6, 7 (own row 7) | 3.29% | 3.37% |
| SC-GBS performance!I8 | 2025-10 | column 1 | `1-((H8-D7)/H8)` | 8, 7, 8 (own row 8) | 3.66% | 3.32% |
| SC-GBS performance!I9 | 2025-11 | column 1 | `1-((H9-D8)/H9)` | 9, 8, 9 (own row 9) | 3.33% | 3.38% |
| SC-GBS performance!I10 | 2025-12 | column 1 | `1-((H10-D9)/H10)` | 10, 9, 10 (own row 10) | 3.32% | 3.40% |

## 4. Pallavaram "Days counted for Average per Day"

These are helper values, not performance figures. The workbook's "Average per Day" cells divide by a number typed into each formula (for example `=B3/10`). For most months that number equals the calendar days, so nothing is stored. Where it differs, the typed number is stored so the average can be reproduced:

| Month | Calendar days | Divisor typed in workbook | Source cell |
|---|---:|---:|---|
| 2025-01 | 31 | 10 | Pallavaram detailed analysis !H3 formula divisor |
| 2026-08 | 31 | 30 | Pallavaram detailed analysis !H22 formula divisor |
| 2026-09 | 30 | 9 | Pallavaram detailed analysis !H23 formula divisor |

## 5. Pallavaram monthly figures vs the sum of daily values

Monthly values come from "Pallavaram detailed analysis" and are kept separate from daily values. Where both exist, they do not always agree:

| Month | Metric | Monthly sheet | Sum of daily values | Days with data | Difference |
|---|---|---:|---:|---:|---:|
| 2025-04 | vehicle_count | 7,330 | 7,406 | 30 | -76 |

35 of 36 month/metric pairs agree exactly.

## Blank cells (kept blank - no record created)

1422 blank daily cells in total. Blank days that fall **before** a later value in the same month (genuine gaps):

| Sheet | Domain | Metric | Blank dates inside the month |
|---|---|---|---|
| May 25 | DLF Cybercity | daily_performance | 2025-05-25 |
| May 25 | Keppel | daily_performance | 2025-05-25 |
| May 25 | ITPC | daily_performance | 2025-05-25 |
| May 25 | SC-GBS | daily_performance | 2025-05-26 |
| July 25 | DLF Cybercity | daily_performance | 2025-07-06 |
| July 25 | Keppel | daily_performance | 2025-07-06 |
| July 25 | ITPC | daily_performance | 2025-07-06 |
| July 25 | SC-GBS | daily_performance | 2025-07-06 |
| Aug '25 | DLF Cybercity | daily_performance | 2025-08-16, 2025-08-17 |
| SEP '25 | DLF Cybercity | daily_performance | 2025-09-20, 2025-09-21 |
| SEP '25 | Keppel | daily_performance | 2025-09-13, 2025-09-14, 2025-09-20, 2025-09-21 |
| SEP '25 | ITPC | daily_performance | 2025-09-20, 2025-09-21 |
| SEP '25 | SC-GBS | daily_performance | 2025-09-20, 2025-09-21 |
| OCT-25 | ITPC | daily_performance | 2025-10-04, 2025-10-05 |
| OCT-25 | SC-GBS | daily_performance | 2025-10-01, 2025-10-26 |
| Nov-25 | Keppel | daily_performance | 2025-11-23 |
| Nov-25 | ITPC | daily_performance | 2025-11-22, 2025-11-23 |
| Jan-26 | Keppel | daily_performance | 2026-01-15, 2026-01-17, 2026-01-18 |
| Jan-26 | ITPC | daily_performance | 2026-01-17, 2026-01-18 |
| Jan-26 | MTC | ridership | 2026-01-15, 2026-01-23 |
| Jan-26 | MTC | revenue | 2026-01-15, 2026-01-23 |
| Jan-26 | MTC | gap | 2026-01-15, 2026-01-23 |
| Mar-26 | Keppel | daily_performance | 2026-03-07, 2026-03-08 |
| Apr-26 | ITPC | daily_performance | 2026-04-11, 2026-04-12 |
| Jul-26 | DLF Cybercity | daily_performance | 2026-07-25, 2026-07-26 |
| Aug-26 | Keppel | daily_performance | 2026-08-01, 2026-08-02, 2026-08-09 |
| Aug-26 | ITPC | daily_performance | 2026-08-01, 2026-08-02 |
| SEP-26 | Keppel | daily_performance | 2026-09-10 |

## Errors

None.

## Warnings

None.

## Notes

- Pallavaram 2025-01-01: the workbook formula B3/10 divides by 10, but the month has 31 days. Stored as helper value "Days counted for Average per Day" = 10.
- Pallavaram 2026-08-01: the workbook formula B22/30 divides by 30, but the month has 31 days. Stored as helper value "Days counted for Average per Day" = 30.
- Pallavaram 2026-09-01: the workbook formula B23/9 divides by 9, but the month has 30 days. Stored as helper value "Days counted for Average per Day" = 9.
- SC-GBS 2026-01-01: month row exists but every value is blank - nothing imported (kept blank).
- SC-GBS 2026-02-01: month row exists but every value is blank - nothing imported (kept blank).
- SC-GBS 2026-03-01: month row exists but every value is blank - nothing imported (kept blank).
- SC-GBS: the two columns headed "Alandur Contribution in CMRL ridership in %" have identical headings. They are stored and displayed only as "column 1" (workbook column I) and "column 2" (workbook column J) until you confirm their meaning.

## Superseded Sheet1 vs the detailed Pallavaram sheet

Sheet1 is NOT imported. It differs from the detailed sheet in 16 value(s):
- 2025-07-01 connectivity_expenditure: Sheet1=236625 vs detailed sheet=238500
- 2025-07-01 difference: Sheet1=-5525 vs detailed sheet=-7400
- 2025-08-01 connectivity_expenditure: Sheet1=219000 vs detailed sheet=221250
- 2025-08-01 difference: Sheet1=-3575 vs detailed sheet=-5825
- 2025-09-01 connectivity_expenditure: Sheet1=231000 vs detailed sheet=227250
- 2025-09-01 difference: Sheet1=9750 vs detailed sheet=13500
- 2025-12-01 connectivity_expenditure: Sheet1=240000 vs detailed sheet=237000
- 2025-12-01 difference: Sheet1=-9745 vs detailed sheet=-6745
- 2026-01-01 connectivity_expenditure: Sheet1=210000 vs detailed sheet=216000
- 2026-01-01 difference: Sheet1=-10610 vs detailed sheet=-16610
- 2026-02-01 connectivity_expenditure: Sheet1=216000 vs detailed sheet=215250
- 2026-02-01 difference: Sheet1=-8026 vs detailed sheet=-7276
- 2026-03-01 monthly_vehicle_count: Sheet1=10474 vs detailed sheet=11268
- 2026-03-01 monthly_revenue: Sheet1=235195 vs detailed sheet=252510
- 2026-03-01 connectivity_expenditure: Sheet1=0 vs detailed sheet=232500
- 2026-03-01 difference: Sheet1=235195 vs detailed sheet=20010

## Cells deliberately not imported

- `April 25!AG1`: column "Average" (derived Total/Average - not a daily value)
- `May 25!A28`: row label "Palalvaram" =  (rate-card note, not a domain metric)
- `May 25!A29`: row label "Mon-Friday-Connectivity per day" = 8850 (rate-card note, not a domain metric)
- `May 25!A30`: row label "Saturday" = 7080 (rate-card note, not a domain metric)
- `May 25!A31`: row label "Sunday" = 3540 (rate-card note, not a domain metric)
- `May 25!A32`: row label "Staff" = 3360 (rate-card note, not a domain metric)
- `June 25!A28`: row label "Palalvaram" =  (rate-card note, not a domain metric)
- `June 25!A29`: row label "Mon-Friday-Connectivity per day" = 8850 (rate-card note, not a domain metric)
- `June 25!A30`: row label "Saturday" = 7080 (rate-card note, not a domain metric)
- `June 25!A31`: row label "Sunday" = 3540 (rate-card note, not a domain metric)
- `June 25!A32`: row label "Staff" = 3360 (rate-card note, not a domain metric)
- `June 25!A34`: row label "Palalvaram" =  (rate-card note, not a domain metric)
- `June 25!A35`: row label "Mon-Friday-Connectivity per day" = 7500 (rate-card note, not a domain metric)
- `June 25!A36`: row label "Saturday" = 6000 (rate-card note, not a domain metric)
- `June 25!A37`: row label "Sunday" = 3000 (rate-card note, not a domain metric)
- `June 25!A38`: row label "Staff" = 3360 (rate-card note, not a domain metric)
- `Jan-26!AH1`: column "Total" (derived Total/Average - not a daily value)
- `Jan-26!AI1`: column "Average" (derived Total/Average - not a daily value)
- `Feb-26!AE1`: column "Total" (derived Total/Average - not a daily value)
- `Feb-26!AF1`: column "Average" (derived Total/Average - not a daily value)
- `Mar-26!AH1`: column "Total" (derived Total/Average - not a daily value)
- `Mar-26!AI1`: column "Average" (derived Total/Average - not a daily value)
- `Apr-26!AG1`: column "Total" (derived Total/Average - not a daily value)
- `Apr-26!AH1`: column "Average" (derived Total/Average - not a daily value)
- `May-26!AH1`: column "Average" (derived Total/Average - not a daily value)
- `Jun-26!AG1`: column "Average" (derived Total/Average - not a daily value)
- `Aug-26!AH1`: column "Average" (derived Total/Average - not a daily value)
- `Pallavaram detailed analysis!row 24 onward`: helper/derived tables below the monthly table (totals, averages, and the "Average Vehicle Count / Capacity / Occupancy Percentage" table, capacity 772). Not imported: they are calculated from the monthly values. Headings seen: row 88: "Consolidated Pallavaram parking Performance (AVERAGE PER DAY)"; row 89: "Month"
- `SC-GBS performance!B31`: value(s) in a row with no month date
- `SC-GBS performance!B32`: value(s) in a row with no month date
- `SC-GBS performance!B33`: value(s) in a row with no month date
- `SC-GBS performance!B35`: value(s) in a row with no month date
- `SC-GBS performance!B37`: value(s) in a row with no month date
- `SC-GBS performance!B39`: value(s) in a row with no month date
- `SC-GBS performance!B41`: value(s) in a row with no month date
- `SC-GBS performance!B43`: value(s) in a row with no month date
- `SC-GBS performance!B45`: value(s) in a row with no month date
- `SC-GBS performance!B47`: value(s) in a row with no month date